class CreateOnTours < ActiveRecord::Migration[5.1]
  def change
    create_table :on_tours do |t|
      t.string :Centre
      t.string :Location
      t.date :Date

      t.timestamps
    end
  end
end
