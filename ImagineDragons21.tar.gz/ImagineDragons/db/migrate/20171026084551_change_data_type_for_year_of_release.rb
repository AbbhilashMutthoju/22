class ChangeDataTypeForYearOfRelease < ActiveRecord::Migration[5.1]
  def change
 change_column :albums, :year_of_release, : Date
  end
end
