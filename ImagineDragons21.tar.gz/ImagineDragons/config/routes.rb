Rails.application.routes.draw do
  get 'main/about_us'

  get 'main/music'

  get 'main/tour_details'

  get 'main/store'

   get 'main/pics'
   get 'main/home'
   get 'main/news'

 

  resources :latest_updates
  devise_for :users
  resources :on_tours
  resources :songs
  resources :albums
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
