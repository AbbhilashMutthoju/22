require "application_system_test_case"

class OnToursTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit on_tours_url
  #
  #   assert_selector "h1", text: "OnTour"
  # end
end
