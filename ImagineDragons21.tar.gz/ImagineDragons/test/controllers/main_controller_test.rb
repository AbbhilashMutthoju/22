require 'test_helper'

class MainControllerTest < ActionDispatch::IntegrationTest
  test "should get about_us" do
    get main_about_us_url
    assert_response :success
  end

  test "should get music" do
    get main_music_url
    assert_response :success
  end

  test "should get tour_details" do
    get main_tour_details_url
    assert_response :success
  end

  test "should get store" do
    get main_store_url
    assert_response :success
  end

  test "should get pics" do
    get main_pics_url
    assert_response :success
  end

end
