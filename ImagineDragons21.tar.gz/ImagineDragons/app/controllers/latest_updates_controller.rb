class LatestUpdatesController < ApplicationController
  before_action :set_latest_update, only: [:show, :edit, :update, :destroy]

  # GET /latest_updates
  # GET /latest_updates.json
  def index
    @latest_updates = LatestUpdate.all
  end

  # GET /latest_updates/1
  # GET /latest_updates/1.json
  def show
  end

  # GET /latest_updates/new
  def new
    @latest_update = LatestUpdate.new
  end

  # GET /latest_updates/1/edit
  def edit
  end

  # POST /latest_updates
  # POST /latest_updates.json
  def create
    @latest_update = LatestUpdate.new(latest_update_params)

    respond_to do |format|
      if @latest_update.save
        format.html { redirect_to @latest_update, notice: 'Latest update was successfully created.' }
        format.json { render :show, status: :created, location: @latest_update }
      else
        format.html { render :new }
        format.json { render json: @latest_update.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /latest_updates/1
  # PATCH/PUT /latest_updates/1.json
  def update
    respond_to do |format|
      if @latest_update.update(latest_update_params)
        format.html { redirect_to @latest_update, notice: 'Latest update was successfully updated.' }
        format.json { render :show, status: :ok, location: @latest_update }
      else
        format.html { render :edit }
        format.json { render json: @latest_update.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /latest_updates/1
  # DELETE /latest_updates/1.json
  def destroy
    @latest_update.destroy
    respond_to do |format|
      format.html { redirect_to latest_updates_url, notice: 'Latest update was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_latest_update
      @latest_update = LatestUpdate.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def latest_update_params
      params.require(:latest_update).permit(:latestnews)
    end
end
