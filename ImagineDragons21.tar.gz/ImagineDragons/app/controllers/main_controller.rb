class MainController < ApplicationController
  def about_us
 render('about_us')
  end

  def music
  end

  def tour_details
  end

  def store
  end

  def pics
  end
  
  def home
  	render('home')
  end
end
